﻿Function Get-Server {
     
    $Searcher = [adsisearcher]""
    If ($Domain = "PHX"){$searchroot = [ADSI]"LDAP://DC=phx,DC=fnbm,DC=corp"}
    elseif ($Domain = "BIZ"){$searchroot = [ADSI]"LDAP://DC=CREDITONEAPP,DC=BIZ" }
    elseif ($Domain = "TST"){$searchroot = [ADSI]"LDAP://DC=CREDITONEAPP,DC=TST"}
    else {$searchroot = [ADSI]"LDAP://DC=fnbm,DC=corp"}
    $Searcher.SearchRoot = $searchroot
    $Searcher.Filter = "(&(objectCategory=computer)(OperatingSystem=Windows*Server*))"
    $Searcher.pagesize = 10
    $Searcher.sizelimit = 5000
    $searcher.PropertiesToLoad.Add("name") | Out-Null
    $Searcher.Sort.PropertyName='name'
    $Searcher.Sort.Direction = 'Ascending'
    $Searcher.FindAll() | ForEach-Object {$_.Properties.name}
}