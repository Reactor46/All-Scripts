using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace SharedMailbox
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public class WebForm1 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.DataGrid dgDatagrid;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			SqlConnection scSQLConnection;
			scSQLConnection = new SqlConnection("Data Source=server;Initial Catalog=SharedMailbox;User Id=username;Password=pass;");
			scSQLConnection.Open();
			SqlDataAdapter daSqlDataAdapter;
			daSqlDataAdapter =  new SqlDataAdapter("Select EntryID,DateSent,FromName,Subject,filename,attachnum from [vwViewMessages@address@domain.com]", scSQLConnection);
			DataSet dsDataset = new DataSet();
			daSqlDataAdapter.Fill(dsDataset, "vwViewMessages");
			dgDatagrid.DataSource = dsDataset.Tables["vwViewMessages"];
			dgDatagrid.DataBind();
			scSQLConnection.Close();
		}
		public void dgDatagrid_ItemDataBound(object sender, DataGridItemEventArgs e)
		{
			string dnDBName = "address@domain.com";
			Int32 anAttachnum;
			e.Item.Cells[2].Text = "<a href=\"showmsg.aspx?Entryid=" 
				+ Convert.ToString(DataBinder.Eval(e.Item.DataItem, "Entryid")) 
				+ "&dbname=" + dnDBName +  "\">" + e.Item.Cells[2].Text.ToString() + "</a>";
			if (DataBinder.Eval(e.Item.DataItem, "attachnum") != DBNull.Value)
			{
				string fnFilename= Convert.ToString(e.Item.Cells[3].Text);
				if (fnFilename.Length > 30) 
				{
					fnFilename.Substring(0,30);
				}
				anAttachnum = Convert.ToInt32(DataBinder.Eval(e.Item.DataItem, "attachnum"));
				e.Item.Cells[3].Text = "<a href=\"attachdownld.aspx?Entryid=" 
					+ Convert.ToString(DataBinder.Eval(e.Item.DataItem, "Entryid")) 
					+ "&attachid=" + anAttachnum  + "&dbname=" + dnDBName + "\">" + fnFilename + "</a>";
			
				if (anAttachnum > 1 & e.Item.ItemIndex != 0)
				{
					e.Item.Cells[0].Text = "";
					e.Item.Cells[1].Text = "";
					e.Item.Cells[2].Text = "";
				}
			}
		}

		public void newpage(object sender, DataGridPageChangedEventArgs e)
		{
			dgDatagrid.CurrentPageIndex = e.NewPageIndex;
			dgDatagrid.DataBind();
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
