using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace SharedMailbox
{
	/// <summary>
	/// Summary description for showmsg.
	/// </summary>
	public class showmsg : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.Label Label3;
		protected System.Web.UI.WebControls.Label lbFromEmail;
		protected System.Web.UI.WebControls.Label lbFromName;
		protected System.Web.UI.WebControls.Label Label4;
		protected System.Web.UI.WebControls.Label lbDateSent;
		protected System.Web.UI.WebControls.Label lbMessageText;
		protected System.Web.UI.WebControls.Label Back;
		protected System.Web.UI.WebControls.Label Reply;
		protected System.Web.UI.WebControls.Label lbSubject;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			SqlConnection scSQLConnection;
			scSQLConnection = new SqlConnection("Data Source=server;Initial Catalog=SharedMailbox;User Id=username;Password=pass;");
			scSQLConnection.Open();
			SqlCommand scdSQLCommand;
			string dnDbname = Request.QueryString.GetValues("dbname").GetValue(0).ToString();
			dnDbname = "inbox@" + dnDbname; 
			string eiEntryid  = Request.QueryString.GetValues("Entryid").GetValue(0).ToString();
			scdSQLCommand = new SqlCommand("Select * from [" + dnDbname + "] where entryid = '"
				+ eiEntryid + "'", scSQLConnection);
			SqlDataReader drDatareader;
			drDatareader = scdSQLCommand.ExecuteReader();
			drDatareader.Read();
			lbFromName.Text = drDatareader["FromName"].ToString();
			lbFromEmail.Text = drDatareader["FromEmail"].ToString();
			lbSubject.Text = drDatareader["Subject"].ToString();
			lbDateSent.Text = drDatareader["DateSent"].ToString();
			lbMessageText.Text = drDatareader["TextBody"].ToString();
			string qsQueryst = "Entryid=" + eiEntryid + "&dbname=" + dnDbname;
			Back.Text =  "<a href=\"javascript:history.back();\">Back</a>";
			Reply.Text = "<a href=\"replymsg.aspx?" + qsQueryst + "\">Reply</a>";
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion



	}
}
