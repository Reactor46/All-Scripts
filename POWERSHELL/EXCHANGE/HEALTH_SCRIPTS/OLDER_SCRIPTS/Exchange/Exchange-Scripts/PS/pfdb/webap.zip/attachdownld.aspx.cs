using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace SharedMailbox
{

	public class attachdownld : System.Web.UI.Page
	{
		private void Page_Load(object sender, System.EventArgs e)
		{
			SqlConnection scSQLConnection;
			scSQLConnection = new SqlConnection("Data Source=server;Initial Catalog=SharedMailbox;User Id=username;Password=pass;");
			scSQLConnection.Open();
			SqlCommand scdSQLCommand;
			string eiEntryid  = Request.QueryString.GetValues("Entryid").GetValue(0).ToString();
			string aiAttachid = Request.QueryString.GetValues("attachid").GetValue(0).ToString();
			string dnDbname = Request.QueryString.GetValues("dbname").GetValue(0).ToString();
			dnDbname = "attachments@" + dnDbname;
			scdSQLCommand = new SqlCommand("Select * from [" + dnDbname + "]attachments where entryid = '"
				+ eiEntryid + "' and attachnum='" + aiAttachid + "'", scSQLConnection);
			SqlDataReader drDatareader;
			drDatareader = scdSQLCommand.ExecuteReader();
			drDatareader.Read();
			CDO.Message mgMessage;
			mgMessage = new CDO.MessageClass();
			ADODB.Stream stAttachmentStream;
			if (drDatareader["ContentType"].ToString() != "message/rfc822")
			{
				CDO.IBodyPart bpBoddypart;
				bpBoddypart = mgMessage.BodyPart.AddBodyPart(-1);
				stAttachmentStream = bpBoddypart.GetStream();
				stAttachmentStream.WriteText(drDatareader["Messagebody"].ToString(), ADODB.StreamWriteEnum.adWriteChar);
				stAttachmentStream.Flush();
				stAttachmentStream.Close();
				stAttachmentStream = bpBoddypart.GetDecodedContentStream();
				if (stAttachmentStream.Type == ADODB.StreamTypeEnum.adTypeText)
				{
					stAttachmentStream.Position = 0;
					stAttachmentStream.Type = ADODB.StreamTypeEnum.adTypeBinary;
				}
				Response.Clear();
				Response.ContentType = drDatareader["contenttype"].ToString();
				Response.AddHeader("Content-Disposition", bpBoddypart.Fields["urn:schemas:mailheader:content-disposition"].Value.ToString());
				Response.AddHeader("Content-length", stAttachmentStream.Size.ToString());
				Response.OutputStream.Write((byte[])stAttachmentStream.Read(-1), 0, stAttachmentStream.Size);
			}
			else 
			{
				stAttachmentStream = new ADODB.Stream();
				stAttachmentStream.Open(System.Reflection.Missing.Value,ADODB.ConnectModeEnum.adModeUnknown,ADODB.StreamOpenOptionsEnum.adOpenStreamUnspecified,"","");
				stAttachmentStream.Type = ADODB.StreamTypeEnum.adTypeText;
				stAttachmentStream.Charset = "x-ansi";
				stAttachmentStream.WriteText(drDatareader["Messagebody"].ToString(), ADODB.StreamWriteEnum.adWriteChar);
				stAttachmentStream.Position = 0;
				stAttachmentStream.Type = ADODB.StreamTypeEnum.adTypeBinary;
				stAttachmentStream.Flush();
				Response.ContentType = drDatareader["contenttype"].ToString();
				Response.AddHeader("Content-Disposition", "attachment; filename=\"" + drDatareader["filename"].ToString() + "\"") ;
				Response.AddHeader("Content-length", stAttachmentStream.Size.ToString());
				Response.OutputStream.Write((byte[])stAttachmentStream.Read(-1), 0, stAttachmentStream.Size);
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
