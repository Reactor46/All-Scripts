using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.Mail;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace SharedMailbox
{
	/// <summary>
	/// Summary description for WebForm3.
	/// </summary>
	public class WebForm3 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.Label Label3;
		protected System.Web.UI.WebControls.TextBox lbSubject;
		protected System.Web.UI.WebControls.TextBox lbFromEmail;
		protected System.Web.UI.WebControls.Label Back;
		protected FreeTextBoxControls.FreeTextBox FreeTextBox2;
		protected System.Web.UI.WebControls.Button Button1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if (Request.ServerVariables["REQUEST_METHOD"] != "POST")
			{ 
				SqlConnection scSQLConnection;
				scSQLConnection = new SqlConnection("Data Source=server;Initial Catalog=SharedMailbox;User Id=username;Password=pass;");
				scSQLConnection.Open();
				SqlCommand scdSQLCommand;
				string dnDbname = Request.QueryString.GetValues("dbname").GetValue(0).ToString();
				string eiEntryid  = Request.QueryString.GetValues("Entryid").GetValue(0).ToString();
				scdSQLCommand = new SqlCommand("Select * from [" + dnDbname + "] where entryid = '"
					+ eiEntryid + "'", scSQLConnection);
				SqlDataReader drDatareader;
				drDatareader = scdSQLCommand.ExecuteReader();
				drDatareader.Read();
				//lbFromName.Text = drDatareader["FromName"].ToString();
				lbFromEmail.Text = drDatareader["FromEmail"].ToString();
				if(drDatareader["Subject"].ToString().Substring(0,3)=="RE:")
				{
					lbSubject.Text = drDatareader["Subject"].ToString();}
				else{
					lbSubject.Text = "RE:" + drDatareader["Subject"].ToString();
				}
				string hdReplyheader = "<BR><BR><hr width=\"100%\" size=\"1\" color=\"#808080\" align=\"left\" noshade>" +
				"<B>From:</B>" + drDatareader["FromName"].ToString() + "[" + drDatareader["FromEmail"].ToString() +"]" + "<BR>" +
				"<B>Sent:</B>" + drDatareader["DateSent"].ToString() + "<BR>" +
				"<B>To:</B>address@domain.com" + "<BR>" +
				"<B>Subject:</B>" + drDatareader["Subject"].ToString();

				FreeTextBox2.Text = hdReplyheader + drDatareader["TextBody"].ToString();}
			}
			

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Button1_Click(object sender, System.EventArgs e)
		{
		string dnDbname = Request.QueryString.GetValues("dbname").GetValue(0).ToString();
		string eiEntryid  = Request.QueryString.GetValues("Entryid").GetValue(0).ToString();
		MailMessage msMessage = new MailMessage();
		msMessage.To = lbFromEmail.Text ;
		msMessage.From = "address@domain.com";
		msMessage.Subject = lbSubject.Text;
		msMessage.Body = FreeTextBox2.Text ;
		msMessage.BodyFormat = MailFormat.Html;
		System.Web.Mail.SmtpMail.SmtpServer = "Mgnms01";
		System.Web.Mail.SmtpMail.Send(msMessage);
		dnDbname = dnDbname.Replace("inbox@","sent@");
        string siSqlinsert = "insert into [" + dnDbname + "] values('" + eiEntryid + "','" + System.DateTime.Now.ToShortDateString() + "','" + 
		lbFromEmail.Text.ToString().Replace("'","''") + "','" + lbSubject.Text.ToString().Replace("'","''") +
		"','" +  FreeTextBox2.Text.ToString().Replace("'","''") + "')";
		SqlConnection scSQLConnection;
		scSQLConnection = new SqlConnection("Data Source=MGNDb01;Initial Catalog=SharedMailbox;User Id=replogon;Password=pass;");
		scSQLConnection.Open();
		SqlCommand scdSQLCommand;
		scdSQLCommand = new SqlCommand(siSqlinsert,scSQLConnection);
		scdSQLCommand.ExecuteNonQuery();
		Response.Redirect("listmsgs.aspx");
		}
	}
}
