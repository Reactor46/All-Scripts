#STARTING CAPS
.\cmdstart-remote-service.ps1 lassvc01 FNBMCheckRequestService
.\cmdstart-remote-service.ps1 lasmerit01 CreditEngine
.\cmdstart-remote-service.ps1 lascapsmt01 NetConnectTransactionsSavingService
.\cmdstart-remote-service.ps1 lassvc01 FNBMLPSService
.\cmdstart-remote-service.ps1 lascapsmt01 BoardingService
.\cmdstart-remote-service.ps1 lascapsmt01 FNBMDebitCardHolderFileWatcher
.\cmdstart-remote-service.ps1 lascapsmt01 FNBMIdentityCheckService
.\cmdstart-remote-service.ps1 lascapsmt01 FromPPSExchangeFileWatcherService
.\cmdstart-remote-service.ps1 lascapsmt01 FNBMIPFraudCheckService
.\cmdstart-remote-service.ps1 lascapsmt01 CreditPullService
.\cmdstart-remote-service.ps1 lascapsmt01 FNBMApplicationProcessingService
.\cmdstart-remote-service.ps1 lascapsmt01 FNBMApplicationImportService
.\cmdstart-remote-service.ps1 lascapsmt01 FNBMApplicationParsingService
#STARTING CAS
.\cmdstart-remote-service.ps1 lassvc01 FNBMQueueProcessorService
.\cmdstart-remote-service.ps1 lascsmt01 FNBMCollectionsConnectorService
.\cmdstart-remote-service.ps1 lascsmt01 FNBMDataLayerService
.\cmdstart-remote-service.ps1 lascasmt02 CacheDataManager
.\cmdstart-remote-service.ps1 lascasmt02 FNBMDataLayerService
.\cmdstart-remote-service.ps1 lascasmt01 CacheDataManager
.\cmdstart-remote-service.ps1 lascasmt01 FNBMDataLayerService
.\cmdstart-remote-service.ps1 LASCSMT01 CreditOneFoxProSideCollectionsReplicationService
.\cmdstart-remote-service.ps1 LASCSMT01 CreditOneOracleSideCollectionsReplicationService
.\cmdstart-remote-service.ps1 LASIBIZ03 AIS iBizflow Server
.\cmdstart-remote-service.ps1 LASIBIZ04 AIS iBizflow Server
.\cmdstart-remote-service.ps1 LASSVC01 CentralizedCacheService
.\cmdstart-remote-service.ps1 LASSVC01 CreditOne.LogParser.Service
.\cmdstart-remote-service.ps1 LASSVC01 CollectionsAgentTimeService
.\cmdstart-remote-service.ps1 LASCOLL01 FNBMDataLayerService
.\cmdstart-remote-service.ps1 LASCOLL02 FNBMDataLayerService
.\cmdstart-remote-service.ps1 LASCOLL03 FNBMDataLayerService
.\cmdstart-remote-service.ps1 LASCOLL04 FNBMDataLayerService