﻿#STOP CAPS
.\cmdstop-remote-service.ps1 lascapsmt01 FNBMApplicationParsingService
.\cmdstop-remote-service.ps1 lascapsmt01 FNBMApplicationImportService
.\cmdstop-remote-service.ps1 lascapsmt01 FNMBApplicationProcessingService
.\cmdstop-remote-service.ps1 lascapsmt01 CreditPullService
.\cmdstop-remote-service.ps1 lascapsmt01 FNBMIPFraudCheckService
.\cmdstop-remote-service.ps1 lascapsmt01 FromPPSExchangeFileWatcherService
.\cmdstop-remote-service.ps1 lascapsmt01 FNBMIdentityCheckService
.\cmdstop-remote-service.ps1 lascapsmt01 FNBMDebitCardHolderFileWatcher
.\cmdstop-remote-service.ps1 lascapsmt01 BoardingService
.\cmdstop-remote-service.ps1 lassvc01 FNBMLPSService
.\cmdstop-remote-service.ps1 lascapsmt01 NetConnectTransactionsSavingService
.\cmdstop-remote-service.ps1 lasmerit01 CreditEngine
.\cmdstop-remote-service.ps1 lassvc01 FNBMCheckRequestService
#STOP CAS
.\cmdstop-remote-service.ps1 lassvc01 FNBMQueueProcessorService
.\cmdstop-remote-service.ps1 lascsmt01 FNBMCollectionsConnectorService
.\cmdstop-remote-service.ps1 lascsmt01 FNBMDataLayerService
.\cmdstop-remote-service.ps1 lascasmt02 CacheDataManager
.\cmdstop-remote-service.ps1 lascasmt02 FNBMDataLayerService
.\cmdstop-remote-service.ps1 lascasmt01 CacheDataManager
.\cmdstop-remote-service.ps1 lascasmt01 FNBMDataLayerService
.\cmdstop-remote-service.ps1 LASCSMT01 CreditOneFoxProSideCollectionsReplicationService
.\cmdstop-remote-service.ps1 LASCSMT01 CreditOneOracleSideCollectionsReplicationService
.\cmdstop-remote-service.ps1 LASIBIZ03 AIS iBizflow Server
.\cmdstop-remote-service.ps1 LASIBIZ04 AIS iBizflow Server
.\cmdstop-remote-service.ps1 LASSVC01 CentralizedCacheService
.\cmdstop-remote-service.ps1 LASSVC01 CreditOne.LogParser.Service
.\cmdstop-remote-service.ps1 LASSVC01 CollectionsAgentTimeService
.\cmdstop-remote-service.ps1 LASCOLL01 FNBMDataLayerService
.\cmdstop-remote-service.ps1 LASCOLL02 FNBMDataLayerService
.\cmdstop-remote-service.ps1 LASCOLL03 FNBMDataLayerService
.\cmdstop-remote-service.ps1 LASCOLL04 FNBMDataLayerService